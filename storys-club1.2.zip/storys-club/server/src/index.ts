import * as express from "express";
import * as path from "path";

const app = express();
// дозволяє серверу читати JSON з браузера
app.use(express.json());
const PORT = 3000;

// шлях до папки де лежить storys-club.html
const publicPath = path.join(__dirname, "../../");

// дозволяє відкривати файли (html, картинки і т.д.)
app.use(express.static(publicPath));

// коли заходиш на сайт → відкриває storys-club.html
app.get("/", (req, res) => {
  res.sendFile(path.join(publicPath, "storys-club.html"));
});
import * as fs from "fs";

// папка для історій
const storiesPath = path.join(__dirname, "../../stories");
// папка для користувачів
const usersPath = path.join(process.cwd(), "../users");

if (!fs.existsSync(usersPath)) {
  fs.mkdirSync(usersPath);
}

// якщо папки нема — створюємо
if (!fs.existsSync(storiesPath)) {
  fs.mkdirSync(storiesPath);
}
app.post("/api/register", (req, res) => {

  const { username, password } = req.body;

  const filePath = path.join(usersPath, username + ".json");

  if (fs.existsSync(filePath)) {
    return res.json({ error: "User exists" });
  }

  const user = {
    id: Date.now(),
    username,
    password
  };

  fs.writeFileSync(filePath, JSON.stringify(user, null, 2));

  res.json({ success: true, userId: user.id });
});
app.post("/api/login", (req, res) => {

  const { username, password } = req.body;

  const filePath = path.join(usersPath, username + ".json");

  if (!fs.existsSync(filePath)) {
    return res.json({ error: "User not found" });
  }

  const user = JSON.parse(fs.readFileSync(filePath, "utf-8"));

  if (user.password !== password) {
    return res.json({ error: "Wrong password" });
  }

  res.json({ success: true, userId: user.id });
});
// POST → створення файлу
app.post("/api/create", (req, res) => {


  const { title, content, autor} = req.body;

  // унікальне ім'я файлу
  const fileName = Date.now() + ".json";

  const filePath = path.join(storiesPath, fileName,);

  const data = {
    name: title,
    story: content,
	autor: autor
  };

  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

  res.json({ success: true });
});
app.get("/api/search", (req, res) => {
  const query = req.query.q?.toString().toLowerCase();

  if (!query) {
    return res.json([]);
  }
const files = fs.readdirSync(storiesPath)
  .filter(file => file.endsWith(".json"));
const results = files.map(file => {

  const data = JSON.parse(
    fs.readFileSync(path.join(storiesPath, file), "utf8")
  );

  return data;

}).filter(story => {

  const title = (story.title || "").toLowerCase();
  const content = (story.content || "").toLowerCase();

  return title.includes(query) || content.includes(query);

});
  res.json(results);
});
app.listen(PORT, () => {
  console.log("Yuhu! Server running: http://localhost:3000");
});