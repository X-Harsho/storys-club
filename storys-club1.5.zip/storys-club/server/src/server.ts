import express from "express";

const app = express();
app.use(express.json());

app.get("/api/ping", (req, res) => {
  res.json({ message: "Server is alive" });
});

app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
